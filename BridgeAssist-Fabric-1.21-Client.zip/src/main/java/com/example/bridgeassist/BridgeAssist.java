
package com.example.bridgeassist;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class BridgeAssist {

    private static boolean enabled = false;
    private static Mode mode = Mode.SPEED;

    private static long lastPlaceTime = 0;
    private static int cps = 10; // max 15

    public static void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        if (Keybinds.toggle.wasPressed()) enabled = !enabled;
        if (Keybinds.speed.wasPressed()) mode = Mode.SPEED;
        if (Keybinds.telly.wasPressed()) mode = Mode.TELLY;
        if (Keybinds.god.wasPressed()) mode = Mode.GOD;

        if (!enabled) return;

        client.player.setPitch(80.0F);

        if (mode == Mode.GOD) return;

        BlockPos below = client.player.getBlockPos().down();

        if (!client.world.getBlockState(below).isAir()) return;

        int effectiveCps = (mode == Mode.TELLY) ? 13 : cps;
        long delay = 1000L / Math.min(effectiveCps, 15);
        long now = System.currentTimeMillis();

        if (now - lastPlaceTime < delay) {
            client.player.input.movementForward = 0;
            return;
        }

        BlockHitResult hit = new BlockHitResult(
                client.player.getPos(),
                Direction.DOWN,
                below,
                false
        );

        client.interactionManager.interactBlock(
                client.player,
                Hand.MAIN_HAND,
                hit
        );

        lastPlaceTime = now;
    }
}
