
package com.example.bridgeassist;

public enum Mode {
    SPEED,
    TELLY,
    GOD
}
