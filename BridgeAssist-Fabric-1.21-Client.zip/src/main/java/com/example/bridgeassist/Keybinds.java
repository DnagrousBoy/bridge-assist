
package com.example.bridgeassist;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public class Keybinds {

    public static KeyBinding toggle;
    public static KeyBinding speed;
    public static KeyBinding telly;
    public static KeyBinding god;

    public static void register() {
        toggle = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("Toggle BridgeAssist", GLFW.GLFW_KEY_G, "BridgeAssist")
        );

        speed = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("BridgeAssist Speed Mode", GLFW.GLFW_KEY_H, "BridgeAssist")
        );

        telly = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("BridgeAssist Telly Mode", GLFW.GLFW_KEY_J, "BridgeAssist")
        );

        god = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("BridgeAssist God Mode", GLFW.GLFW_KEY_K, "BridgeAssist")
        );
    }
}
