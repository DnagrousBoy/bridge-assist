
package com.example.bridgeassist;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class BridgeAssistMod implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        Keybinds.register();
        ClientTickEvents.END_CLIENT_TICK.register(client -> BridgeAssist.onTick(client));
    }
}
